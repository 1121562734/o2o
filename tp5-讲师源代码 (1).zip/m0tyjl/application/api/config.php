<?php
//配置文件
return [
    'default_return_type' => 'json',
];